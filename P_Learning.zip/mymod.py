def americano(money):
    cup = int(money / 1500)
    rem = money % 1500
    return cup, rem

def totaler(until, even=True):
    '''even 변수에 따라 홀수/짝수 계산'''
    total = 0
    cmp = 0 if even else 1
    for n in range(until+1):
        if n%2 ==cmp:
            total += n
    return total

def calculator(num1:int|float, op:str, num2:int|float):
    match(op):
        case '+': return num1+num2
        case '-': return num1-num2
        case '*': return num1*num2
        case '/': return num1/num2
        case _: return None
        
def sum_avg(nums:list|tuple):
    tot = sum(nums)          # nums의 값 합산
    avg = tot/len(nums)
    return tot, avg

def week_day_from_num(n:str):
    match n:
        case '0': return '일요일'
        case '1': return '월요일'
        case '2': return '화요일'
        case '3': return '수요일'
        case '4': return '목요일'
        case '5': return '금요일'
        case '6': return '토요일'
        case _: return None
